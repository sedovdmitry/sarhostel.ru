$(function(){

	$('#myform').idealforms();

});